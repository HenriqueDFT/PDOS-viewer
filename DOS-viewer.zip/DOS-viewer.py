import sys
import pandas as pd
import re
import os
import random
from PyQt5.QtWidgets import (QApplication, QMainWindow, QVBoxLayout, QWidget, 
                             QPushButton, QFileDialog, QCheckBox, QHBoxLayout, 
                             QLabel, QLineEdit, QFormLayout, QMessageBox, QColorDialog,
                             QListWidget, QListWidgetItem, QFrame) 
from PyQt5.QtGui import QColor, QIcon, QPixmap
from PyQt5.QtCore import QSize, Qt, QTimer

# Importações do Matplotlib
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

# --- FUNÇÃO ADICIONAL PARA GARANTIR VALORES ZERO NAS EXTREMIDADES ---
def ensure_zero_at_bounds(df):
    if df.empty:
        return df
    min_energy = df['Energy'].min()
    max_energy = df['Energy'].max()
    df_start = pd.DataFrame([{'Energy': min_energy, 'DOS': 0.0, 'Energy_original': df['Energy_original'].min()}])
    df_end = pd.DataFrame([{'Energy': max_energy, 'DOS': 0.0, 'Energy_original': df['Energy_original'].max()}])
    df_new = pd.concat([df_start, df, df_end]).drop_duplicates(subset=['Energy']).sort_values('Energy').reset_index(drop=True)
    return df_new

# --- 1. FUNÇÃO DE PROCESSAMENTO DE DADOS ---
def parse_pdos_file(filepath, fermi_reference=None):
    try:
        with open(filepath, 'r') as f:
            content = f.read()
        fermi_from_file = None
        fermi_energy_match = re.search(r'Fermi energy : ([-+]?\d+\.\d+)', content)
        if fermi_energy_match:
            fermi_from_file = float(fermi_energy_match.group(1))
        if fermi_reference is not None:
            fermi_to_use = fermi_reference
            if fermi_from_file is not None and fermi_from_file != fermi_reference:
                print(f"Aviso: Fermi do arquivo ({fermi_from_file}) diferente do Fermi de referência ({fermi_reference}) para {os.path.basename(filepath)}. Usando referência.")
        elif fermi_from_file is not None:
            fermi_to_use = fermi_from_file
        else:
            print(f"Aviso: Nível de Fermi não encontrado e nenhum de referência fornecido para {os.path.basename(filepath)}. Usando 0.0.")
            fermi_to_use = 0.0
        data_lines = [line.strip() for line in content.split('\n') if not line.strip().startswith('#') and len(line.strip().split()) == 2]
        df = pd.read_csv(pd.io.common.StringIO('\n'.join(data_lines)), delim_whitespace=True, header=None, names=['Energy', 'DOS'])
        df['Energy_original'] = df['Energy'].copy() 
        df['Energy'] = df['Energy_original'] - fermi_to_use
        df = ensure_zero_at_bounds(df)
        return df, fermi_to_use
    except Exception as e:
        print(f"Erro ao processar o arquivo {os.path.basename(filepath)}: {e}")
        return None, None
        
def parse_bands_file(filepath):
    try:
        with open(filepath, 'r') as f:
            first_line = f.readline()
        fermi_energy = float(first_line.strip().split()[0])
        return fermi_energy
    except Exception as e:
        print(f"Erro ao ler o nível de Fermi do arquivo {os.path.basename(filepath)}: {e}")
        return None

# --- CLASSE DA TELA DE INTRODUÇÃO (POP-UP) ---
class SplashScreen(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        # Tamanho aumentado para garantir que todo o texto apareça
        self.setFixedSize(700, 700) 
        # Removido Qt.FramelessWindowHint para permitir mover a janela
        self.setWindowFlags(Qt.WindowStaysOnTopHint) # Mantém a janela no topo
        self.setStyleSheet("""
            QWidget {
                background-color: #f0f0f0;
                border: none; /* Borda removida */
                border-radius: 10px;
                color: #333;
                font-family: "Segoe UI", "Helvetica Neue", "Arial", sans-serif;
            }
            QLabel {
                border: none; 
            }
            QPushButton {
                background-color: #007bff;
                color: white;
                border-radius: 5px;
                padding: 10px 20px;
                font-size: 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #0056b3;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        # Top logos layout
        top_layout = QHBoxLayout()
        gnc_logo = QLabel()
        ufpi_logo = QLabel()
        try:
            gnc_logo.setPixmap(QPixmap('imagens/gnc.png').scaled(100, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation))
            ufpi_logo.setPixmap(QPixmap('imagens/ufpi.png').scaled(100, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        except FileNotFoundError:
            gnc_logo.setText("GNC Logo Missing")
            ufpi_logo.setText("UFPI Logo Missing")
            gnc_logo.setAlignment(Qt.AlignCenter)
            ufpi_logo.setAlignment(Qt.AlignCenter)
            gnc_logo.setStyleSheet("border: 1px dashed gray;")
            ufpi_logo.setStyleSheet("border: 1px dashed gray;")

        top_layout.addWidget(gnc_logo)
        top_layout.addStretch()
        top_layout.addWidget(ufpi_logo)
        layout.addLayout(top_layout)

        # Main description and authorship
        description_text = """
        <h2 style="text-align: center; color: #007bff;">Visualizador de Densidade de Estados</h2>
        <p style="text-align: justify; line-height: 1.5;">Este software foi desenvolvido para auxiliar na análise e visualização de arquivos de Densidade de Estados (PDOS), permitindo o carregamento de múltiplos arquivos, a normalização por um nível de Fermi de referência e a personalização de cores e legendas.</p>
        <p style="text-align: justify; font-size: 13px; line-height: 1.5;">O software foi criado por Henrique Lago, físico formado pela Universidade Federal do Piauí (UFPI), durante sua Iniciação Científica Voluntária, sob orientação do Professor Dr. Ramon Sampaio Ferreira. O desenvolvimento ocorreu no âmbito do Grupo de Nanofísica Computacional (GNC) da UFPI.</p>
        <p style="text-align: center; font-weight: bold;">Conheça mais sobre o grupo escaneando o QR Code abaixo:</p>
        """
        description_label = QLabel(description_text)
        # Removido Qt.AlignCenter do description_label pois o texto já é justificado
        description_label.setWordWrap(True)
        layout.addWidget(description_label)

        # QR Code and email
        qr_layout = QHBoxLayout()
        qr_label = QLabel()
        try:
            qr_label.setPixmap(QPixmap('imagens/qr.png').scaled(150, 150, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        except FileNotFoundError:
            qr_label.setText("QR Code Missing")
            qr_label.setAlignment(Qt.AlignCenter)
            qr_label.setStyleSheet("border: 1px dashed gray;")

        qr_layout.addStretch()
        qr_layout.addWidget(qr_label)
        qr_layout.addStretch()
        layout.addLayout(qr_layout)

        email_label = QLabel("Para colaborações: <a href='mailto:henrique.liberato@ufpi.edu.br' style='color: #007bff; text-decoration: none;'>henrique.liberato@ufpi.edu.br</a>")
        email_label.setAlignment(Qt.AlignCenter)
        email_label.setOpenExternalLinks(True)
        layout.addWidget(email_label)

        # Buttons layout
        button_layout = QHBoxLayout()
        self.tutorial_button = QPushButton("Tutorial")
        self.tutorial_button.clicked.connect(self.show_tutorial)
        self.continue_button = QPushButton("Seguir")
        self.continue_button.clicked.connect(self.close_and_open_main)

        button_layout.addStretch()
        button_layout.addWidget(self.tutorial_button)
        button_layout.addSpacing(20) # Espaçamento entre os botões
        button_layout.addWidget(self.continue_button)
        button_layout.addStretch()

        layout.addLayout(button_layout)


    def close_and_open_main(self):
        self.close()
        self.main_window.show()

    def show_tutorial(self):
        tutorial_text = """
        <h3 style="text-align: center;"><b>Guia de Uso do Visualizador de Densidade de Estados</b></h3>
        <p>Este software foi projetado para visualizar arquivos de Densidade de Estados (DOS) e Densidade de Estados Parciais (PDOS).</p>
        <p><b>Para o funcionamento, é necessário:</b></p>
        <ul>
            <li><b>Arquivos PDOS (.dat):</b> Os dados de DOS ou PDOS que serão plotados.</li>
            <li><b>Arquivos de Bandas (.bands):</b> (Opcional) Usado para carregar o Nível de Fermi ($E_F$) para normalizar a energia.</li>
        </ul>
      <p><b>Siga estes passos para plotar seus gráficos:</b></p>
        <ol>
            <li>
                <b>Carregar o Nível de Fermi (Recomendado):</b><br>
                Clique no botão "Carregar Nível de Fermi (.bands)". Selecionar um arquivo de bandas é a forma ideal de garantir que o ponto de energia zero (0.0 eV) corresponda exatamente ao Nível de Fermi do seu material.
            </li>
            <li>
                <b>Carregar os Dados de Densidade de Estados:</b><br>
                Clique em "Carregar Arquivos PDOS". Você pode selecionar um ou mais arquivos de uma só vez.
            </li>
            <li>
                <b>Personalizar as Curvas:</b><br>
                Na lista "Curvas Plotadas", clique no nome de uma curva. No painel que aparece abaixo, você pode:
                <ul>
                    <li>Alterar o nome da legenda.</li>
                    <li>Mudar a cor da curva.</li>
                </ul>
            </li>
            <li>
                <b>Ajustar o Gráfico:</b><br>
                Use as opções na seção "Personalização do Gráfico" para ajustar o visual:
                <ul>
                    <li>Ative o "Inverter Eixos" para ter o DOS no eixo X e a Energia no eixo Y.</li>
                    <li>Ajuste os valores mínimos e máximos dos eixos de Energia e DOS.</li>
                    <li>Defina o espaçamento entre as marcas de cada eixo.</li>
                </ul>
            </li>
            <li>
                <b>Exportar o Gráfico:</b><br>
                Quando o gráfico estiver pronto, use os botões "Exportar Gráfico (PNG)" ou "Exportar Gráfico (PDF)" para salvá-lo em alta qualidade.
            </li>
        </ol>
        """
        QMessageBox.information(self, "Tutorial de Uso", tutorial_text)


# --- CLASSE DA INTERFACE GRÁFICA PRINCIPAL ---
class PDOSVisualizer(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Visualizador de PDOS")
        self.setGeometry(100, 100, 1400, 800)
        
        self.loaded_data = {}
        self.fermi_reference = None
        self.selected_filepath = None
        
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QHBoxLayout(main_widget)

        left_panel_layout = QVBoxLayout()
        main_layout.addLayout(left_panel_layout, 1)

        load_buttons_layout = QVBoxLayout()
        load_buttons_layout.addWidget(QLabel("Carregamento de Dados"))
        self.load_fermi_button = QPushButton("Carregar Nível de Fermi (.bands)")
        self.load_fermi_button.clicked.connect(self.load_fermi_reference)
        load_buttons_layout.addWidget(self.load_fermi_button)
        self.load_pdos_button = QPushButton("Carregar Arquivos PDOS")
        self.load_pdos_button.clicked.connect(self.load_pdos_files)
        load_buttons_layout.addWidget(self.load_pdos_button)
        left_panel_layout.addLayout(load_buttons_layout)

        left_panel_layout.addWidget(QLabel("Curvas Plotadas"))
        self.pdos_list_widget = QListWidget()
        self.pdos_list_widget.setSelectionMode(QListWidget.SingleSelection)
        self.pdos_list_widget.itemSelectionChanged.connect(self.handle_selection_change)
        left_panel_layout.addWidget(self.pdos_list_widget)

        # Painel de personalização da curva
        self.customization_frame = QFrame()
        self.customization_frame.setFrameShape(QFrame.StyledPanel)
        customization_layout = QFormLayout(self.customization_frame)
        customization_layout.addWidget(QLabel("Personalizar Curva Selecionada"))
        
        self.label_input = QLineEdit()
        self.label_input.editingFinished.connect(self.update_label)
        customization_layout.addRow("Nome da Legenda:", self.label_input)
        
        self.color_button = QPushButton("Alterar Cor")
        self.color_button.clicked.connect(self.select_plot_color)
        customization_layout.addRow("Cor da Curva:", self.color_button)

        self.customization_frame.hide()
        left_panel_layout.addWidget(self.customization_frame)
        
        # Painel de configurações gerais
        axis_settings_layout = QFormLayout()
        axis_settings_layout.addWidget(QLabel("Personalização do Gráfico"))
        self.invert_checkbox = QCheckBox("Inverter Eixos (DOS vs Energia)")
        self.invert_checkbox.stateChanged.connect(self.update_plot)
        axis_settings_layout.addWidget(self.invert_checkbox)
        self.show_fermi_checkbox = QCheckBox("Mostrar Nível de Fermi")
        self.show_fermi_checkbox.setChecked(True)
        self.show_fermi_checkbox.stateChanged.connect(self.update_plot)
        axis_settings_layout.addWidget(self.show_fermi_checkbox)
        self.energy_min_input = QLineEdit()
        self.energy_min_input.setPlaceholderText("Auto")
        self.energy_min_input.editingFinished.connect(self.update_plot)
        axis_settings_layout.addRow("Eixo Energia Min:", self.energy_min_input)
        self.energy_max_input = QLineEdit()
        self.energy_max_input.setPlaceholderText("Auto")
        self.energy_max_input.editingFinished.connect(self.update_plot)
        axis_settings_layout.addRow("Eixo Energia Max:", self.energy_max_input)
        self.dos_min_input = QLineEdit()
        self.dos_min_input.setPlaceholderText("Auto")
        self.dos_min_input.editingFinished.connect(self.update_plot)
        axis_settings_layout.addRow("Eixo DOS Min:", self.dos_min_input)
        self.dos_max_input = QLineEdit()
        self.dos_max_input.setPlaceholderText("Auto")
        self.dos_max_input.editingFinished.connect(self.update_plot)
        axis_settings_layout.addRow("Eixo DOS Max:", self.dos_max_input)
        self.xtick_spacing_input = QLineEdit()
        self.xtick_spacing_input.setPlaceholderText("Auto")
        self.xtick_spacing_input.editingFinished.connect(self.update_plot)
        axis_settings_layout.addRow("Espaçamento Eixo X:", self.xtick_spacing_input)
        self.ytick_spacing_input = QLineEdit()
        self.ytick_spacing_input.setPlaceholderText("Auto")
        self.ytick_spacing_input.editingFinished.connect(self.update_plot)
        axis_settings_layout.addRow("Espaçamento Eixo Y:", self.ytick_spacing_input)
        left_panel_layout.addLayout(axis_settings_layout)

        export_buttons_layout = QVBoxLayout()
        export_buttons_layout.addWidget(QLabel("Exportar Gráfico"))
        self.export_png_button = QPushButton("Exportar Gráfico (PNG)")
        self.export_png_button.clicked.connect(lambda: self.export_plot('png'))
        export_buttons_layout.addWidget(self.export_png_button)
        self.export_pdf_button = QPushButton("Exportar Gráfico (PDF)")
        self.export_pdf_button.clicked.connect(lambda: self.export_plot('pdf'))
        export_buttons_layout.addWidget(self.export_pdf_button)
        left_panel_layout.addLayout(export_buttons_layout)
        left_panel_layout.addStretch()

        right_panel_layout = QVBoxLayout()
        main_layout.addLayout(right_panel_layout, 3)
        self.figure = Figure(figsize=(8, 6))
        self.canvas = FigureCanvas(self.figure)
        right_panel_layout.addWidget(self.canvas)
        
        self.update_plot()

    def handle_selection_change(self):
        selected_items = self.pdos_list_widget.selectedItems()
        if selected_items:
            selected_item = selected_items[0]
            self.selected_filepath = selected_item.data(Qt.UserRole)
            self.customization_frame.show()
            self.update_customization_panel()
        else:
            self.selected_filepath = None
            self.customization_frame.hide()

    def update_customization_panel(self):
        if self.selected_filepath and self.selected_filepath in self.loaded_data:
            data = self.loaded_data[self.selected_filepath]
            self.label_input.setText(data['label'])
            color_name = data['color'] if data['color'] else "black"
            self.color_button.setStyleSheet(f"background-color: {color_name};")
    
    def update_label(self):
        if self.selected_filepath and self.selected_filepath in self.loaded_data:
            new_label = self.label_input.text()
            self.loaded_data[self.selected_filepath]['label'] = new_label
            for i in range(self.pdos_list_widget.count()):
                item = self.pdos_list_widget.item(i)
                if item.data(Qt.UserRole) == self.selected_filepath:
                    item.setText(new_label)
                    break
            self.update_plot()

    def select_plot_color(self):
        if self.selected_filepath and self.selected_filepath in self.loaded_data:
            initial_color_name = self.loaded_data[self.selected_filepath]['color']
            initial_color = QColor(initial_color_name) if initial_color_name else QColor("blue")
            color = QColorDialog.getColor(initial_color, self, "Selecione a nova cor para a curva")
            if color.isValid():
                new_color_name = color.name()
                self.loaded_data[self.selected_filepath]['color'] = new_color_name
                self.color_button.setStyleSheet(f"background-color: {new_color_name};")
                self.update_plot()
        else:
            QMessageBox.warning(self, "Erro", "Nenhum arquivo selecionado.")
            
    def load_fermi_reference(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Selecionar arquivo .bands", "", "Arquivos de Bandas (*.bands)")
        if file_path:
            fermi_value = parse_bands_file(file_path)
            if fermi_value is not None:
                self.fermi_reference = fermi_value
                print(f"Nível de Fermi de referência carregado: {self.fermi_reference} eV")
                if self.loaded_data:
                    self.apply_fermi_to_loaded_data()
                self.update_plot()

    def apply_fermi_to_loaded_data(self):
        if self.fermi_reference is not None:
            for path, data_dict in self.loaded_data.items():
                data_df = data_dict['df']
                if 'Energy_original' not in data_df.columns:
                     data_df['Energy_original'] = data_df['Energy']
                data_df['Energy'] = data_df['Energy_original'] - self.fermi_reference
            print("Nível de Fermi de referência aplicado aos dados carregados.")
        else:
            print("Nenhum nível de Fermi de referência para aplicar.")

    def load_pdos_files(self): 
        file_paths, _ = QFileDialog.getOpenFileNames(self, "Selecionar arquivos PDOS", "", "Arquivos PDOS (*.dat)")
        if file_paths:
            for path in file_paths:
                if path in self.loaded_data:
                    QMessageBox.information(self, "Arquivo Já Carregado", f"O arquivo {os.path.basename(path)} já está carregado e plotado.")
                    continue
                df, _ = parse_pdos_file(path, fermi_reference=self.fermi_reference)
                if df is not None:
                    label = os.path.basename(path).replace('.dat', '')
                    random_color = "#%06x" % random.randint(0, 0xFFFFFF)
                    self.loaded_data[path] = {'df': df, 'color': random_color, 'label': label} 
                    list_item = QListWidgetItem(label)
                    list_item.setData(Qt.UserRole, path)
                    self.pdos_list_widget.addItem(list_item)
            self.update_plot()

    def update_plot(self):
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        if not self.loaded_data:
            ax.text(0.5, 0.5, 'Nenhum dado carregado. Por favor, carregue um arquivo.', ha='center', va='center', transform=ax.transAxes)
            self.canvas.draw()
            return
        inverted = self.invert_checkbox.isChecked()
        show_fermi = self.show_fermi_checkbox.isChecked()

        for path, data_dict in self.loaded_data.items():
            data = data_dict['df']
            color = data_dict['color']
            label = data_dict['label']
            
            if inverted:
                ax.plot(data['DOS'], data['Energy'], label=label, color=color)
            else:
                ax.plot(data['Energy'], data['DOS'], label=label, color=color)

        if inverted:
            ax.set_xlabel('DOS (unidades arbitrárias)')
            ax.set_ylabel('Energia (eV)')
            if show_fermi:
                ax.axhline(0, color='gray', linestyle='--', label='Nível de Fermi ($E_F$)')
            try:
                if self.dos_min_input.text() or self.dos_max_input.text():
                    dos_min = float(self.dos_min_input.text()) if self.dos_min_input.text() else None
                    dos_max = float(self.dos_max_input.text()) if self.dos_max_input.text() else None
                    ax.set_xlim(dos_min, dos_max)
                if self.energy_min_input.text() or self.energy_max_input.text():
                    energy_min = float(self.energy_min_input.text()) if self.energy_min_input.text() else None
                    energy_max = float(self.energy_max_input.text()) if self.energy_max_input.text() else None
                    ax.set_ylim(energy_min, energy_max)
                if self.xtick_spacing_input.text():
                    ax.xaxis.set_major_locator(ticker.MultipleLocator(float(self.xtick_spacing_input.text())))
                if self.ytick_spacing_input.text():
                    ax.yaxis.set_major_locator(ticker.MultipleLocator(float(self.ytick_spacing_input.text())))
            except ValueError:
                QMessageBox.warning(self, "Erro de Entrada", "Por favor, insira números válidos para os limites ou espaçamento dos eixos.")
        else:
            ax.set_xlabel('Energia (eV)')
            ax.set_ylabel('DOS (unidades arbitrárias)')
            if show_fermi:
                ax.axvline(0, color='gray', linestyle='--', label='Nível de Fermi ($E_F$)')
            try:
                if self.energy_min_input.text() or self.energy_max_input.text():
                    energy_min = float(self.energy_min_input.text()) if self.energy_min_input.text() else None
                    energy_max = float(self.energy_max_input.text()) if self.energy_max_input.text() else None
                    ax.set_xlim(energy_min, energy_max)
                if self.dos_min_input.text() or self.dos_max_input.text():
                    dos_min = float(self.dos_min_input.text()) if self.dos_min_input.text() else None
                    dos_max = float(self.dos_max_input.text()) if self.dos_max_input.text() else None
                    ax.set_ylim(dos_min, dos_max)
                if self.xtick_spacing_input.text():
                    ax.xaxis.set_major_locator(ticker.MultipleLocator(float(self.xtick_spacing_input.text())))
                if self.ytick_spacing_input.text():
                    ax.yaxis.set_major_locator(ticker.MultipleLocator(float(self.ytick_spacing_input.text())))
            except ValueError:
                QMessageBox.warning(self, "Erro de Entrada", "Por favor, insira números válidos para os limites ou espaçamento dos eixos.")
        ax.set_title("Densidade de Estados (DOS)")
        ax.legend()
        ax.grid(True, linestyle=':', alpha=0.6)
        self.figure.tight_layout()
        self.canvas.draw()
        
    def export_plot(self, format):
        if not self.loaded_data:
            QMessageBox.warning(self, "Exportar Gráfico", "Nenhum dado para exportar.")
            return
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getSaveFileName(self, f"Salvar Gráfico como .{format}", "", 
                                                   f"Arquivos {format.upper()} (*.{format});;Todos os Arquivos (*)", options=options)
        if file_name:
            try:
                self.figure.savefig(file_name, format=format, bbox_inches='tight', dpi=300)
                QMessageBox.information(self, "Exportação Sucesso", f"Gráfico salvo como '{file_name}'")
            except Exception as e:
                QMessageBox.critical(self, "Erro de Exportação", f"Não foi possível salvar o gráfico: {e}")

# --- BLOCO PRINCIPAL DE EXECUÇÃO ---
if __name__ == "__main__":
    app = QApplication(sys.argv)
    main_window = PDOSVisualizer()
    splash = SplashScreen(main_window)
    splash.show()
    sys.exit(app.exec_())
